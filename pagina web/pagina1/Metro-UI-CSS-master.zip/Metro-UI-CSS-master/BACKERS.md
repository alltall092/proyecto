<h1 align="center">Sponsors &amp; Backers</h1>

Metro 4 is an MIT-licensed open source project. 
It's an independent project with its ongoing development made possible entirely thanks to the support by these awesome Backers. 
If you'd like to join them, please consider:

- [Become a backer or sponsor on Patreon](https://www.patreon.com/metroui)
- [Become a backer or sponsor on Open Collective](https://opencollective.com/metro4#backer)

<hr>

##### Patreon

![Sponsors on Patreon](https://img.shields.io/badge/backers-2-red.svg)
![Sponsors on Patreon](https://img.shields.io/badge/sponsors-1-red.svg)
![Sponsors on Patreon](https://img.shields.io/badge/donation-$119-red.svg)

##### Opencollective 

[![Backers on Open Collective](https://opencollective.com/metro4/backers/badge.svg)](#backers) 
[![Sponsors on Open Collective](https://opencollective.com/metro4/sponsors/badge.svg)](#sponsors)
![Sponsors on Patreon](https://img.shields.io/badge/donation-$0-darklime.svg)

<hr>

<!--
<h2 align="center">Platinum sponsor</h2>
-->

<!--
<h2 align="center">Silver sponsor</h2>
-->

<h2 align="center">Bronze sponsor</h2>
<div align="center">
<a href="https://www.patreon.com/user/creators?u=20614229"><span style="forn-size: 24px">Matthew Bezuidenhout</span></a>
</div>

<!--
<h2 align="center">Generous Backers via Patreon ($50+)</h2>
-->

<h2 align="center">Backers via Patreon</h2>

 - [Jonathan](https://www.patreon.com/user/creators?u=10019621) 
 - [Arnaud Dagnelies](https://www.patreon.com/user/creators?u=13947239)
 - [Marcel Wehrstedt](https://www.patreon.com/user/creators?u=16353488)


<hr>
 
Thanks to all who [supported a project](DONORS.md)
